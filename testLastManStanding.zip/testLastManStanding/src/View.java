public class View {//This class is designed to be replaced by a GUI
    //Code to display - Will be shifted to updating something on the GUI
    public static void sayPlayerAction(TestPlayerClass player){
        System.out.println(player+" pulled lever: "+player.isLeverPulled());
    }
}
