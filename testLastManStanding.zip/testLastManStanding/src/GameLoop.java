import java.util.Scanner;

public class GameLoop {
    //-----I N I T I A L I Z A T I O N-----\\
    private int playerCount = 0;
    private static TestPlayerClass players[] = {};

    //-----C O N S T R U C T O R-----\\
    public GameLoop(TestPlayerClass[] array){
        this.players=array;
        this.playerCount=array.length;
    }

    public void run(){//Code to run the game's main loop once
        playerCount= players.length;
        while(playerCount>1) {//This runs the main loop multiple times
            int leverSwitches = 0;
            String scannerOutput="";

            //This loop goes around & receives everyone's input
            for (int x = 0; x < playerCount; x++) {
                scannerOutput = Controller.scannerString();
                playerInputCheck(scannerOutput, x);
            }
            //This loop displays what everyone selected
            for (int x = 0; x < playerCount; x++) {View.sayPlayerAction(players[x]);}

            //Code to squash & eliminate a player
            //Code goes Here
            players[playerCount].setSquashed(true);
            playerCount--;
        }

        //Code to end or rematch

    }

    private static void playerInputCheck(String input, int playerNum){//Code to check a player's input
        if(input==players[playerNum].getYes()){
            players[playerNum].setLeverPulled(true);
        }else if (input==players[playerNum].getNo()){
            players[playerNum].setLeverPulled(false);
        }else {
            System.out.println("Player "+playerNum+", please input your yes or no key");
            input = Controller.scannerString();
            playerInputCheck(input, playerNum);//If the player inputted an invalid response this repeats the scenario
        }
    }
}